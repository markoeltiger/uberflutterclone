import 'package:flutter/material.dart';
import 'package:rider_app/AllScreens/RegestrationScreen.dart';
import 'package:rider_app/AllScreens/loginScreen.dart';
import 'package:rider_app/AllScreens/mainscreen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Taxi Rider App',
      theme: ThemeData(
      fontFamily: "bolt-regular",
        primarySwatch: Colors.blue,
      ),
      initialRoute:LoginScreen.idScreen,
      routes: {
        RegestrationScreen.idScreen:(context) =>RegestrationScreen(),
        LoginScreen.idScreen:(context) =>LoginScreen(),
        MainScreen.idScreen:(context) =>MainScreen(),



      },
      debugShowCheckedModeBanner: false,
    );
  }
}

